<?php
  
    echo $_POST['langue'];

    /* if($_POST['langue'] == "fr"){
     setcookie('langue','fr',time()+3600*24*31);
      
    }
    if($_POST['langue'] == "en"){
     setcookie('langue','en',time()+3600*24*31);
      
    }

    if($_POST['langue'] == "es"){
     setcookie('langue','es',time()+3600*24*31);
      
    }
    if(isset($_COOKIE['fr'])){
      echo "Comment vas-tu ?";
    }

    if(isset($_COOKIE['en'])){
      echo "How do you do ?";
    }

    if(isset($_COOKIE['es'])){
      echo "¿ Cómo estás ?";
    }
      */ // ne fonctionne pas 
?>